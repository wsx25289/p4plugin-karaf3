/*
 * Copyright © 2017 ZTE and others.  All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package org.opendaylight.demo.impl;


import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
//import io.grpc.StatusRuntimeException;
import io.grpc.StatusRuntimeException;
//import io.grpc.examples.GreeterGrpc;
//import io.grpc.examples.Helloworld.HelloReply;
//import io.grpc.examples.Helloworld.HelloRequest;
//import io.grpc.examples.HelloReply;
//import io.grpc.examples.HelloRequest;
import org.opendaylight.demo.impl.proto.GreeterGrpc;
import org.opendaylight.demo.impl.proto.HelloReply;
import org.opendaylight.demo.impl.proto.HelloRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GrpcClient {

    private static final Logger LOG = LoggerFactory.getLogger(GrpcClient.class);

    private final ManagedChannel channel;
    private final GreeterGrpc.GreeterBlockingStub blockingStub;

    public GrpcClient(String ip, Integer port) {
        this(ManagedChannelBuilder.forAddress(ip, port).usePlaintext(true));
    }

    private GrpcClient(ManagedChannelBuilder<?> channelBuilder) {
        channel = channelBuilder.build();
        blockingStub = GreeterGrpc.newBlockingStub(channel);
    }

    public String greet(String name) {
        LOG.info("Will try to greet " + name + " ...");
        HelloRequest request = HelloRequest.newBuilder().setName(name).build();
        HelloReply reply;
        try {
            reply = blockingStub.sayHello(request);
        } catch (StatusRuntimeException e) {
            LOG.info("RPC failed: {}", e.getStatus());
            return null;
        }
        return "Greeting" + reply.getMessage();
    }
}
